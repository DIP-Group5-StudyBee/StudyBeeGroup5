-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 07, 2020 at 12:41 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `meetingrecord`
--

DROP TABLE IF EXISTS `meetingrecord`;
CREATE TABLE IF NOT EXISTS `meetingrecord` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `meeting_id` int(11) DEFAULT NULL,
  `meeting_name` varchar(255) DEFAULT NULL,
  `meeting_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=92 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meetingrecord`
--

INSERT INTO `meetingrecord` (`id`, `user_id`, `meeting_id`, `meeting_name`, `meeting_time`) VALUES
(91, 20, 140, 'test3', '2020-12-11 07:00:00'),
(90, 20, 141, 'testtest', '2020-12-07 19:00:00'),
(89, 20, 140, 'test3', '2020-12-11 07:00:00'),
(88, 8, 138, 'test1', '2020-12-07 18:00:00'),
(87, 8, 140, 'test3', '2020-12-11 07:00:00'),
(86, 8, 140, 'test3', '2020-12-11 07:00:00'),
(85, 8, 139, 'test2', '2020-12-10 06:59:00'),
(84, 8, 138, 'test1', '2020-12-07 18:00:00');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
