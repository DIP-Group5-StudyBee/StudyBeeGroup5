-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 07, 2020 at 12:41 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `meetingevent`
--

DROP TABLE IF EXISTS `meetingevent`;
CREATE TABLE IF NOT EXISTS `meetingevent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `meeting_name` varchar(255) DEFAULT NULL,
  `host_name` varchar(255) DEFAULT NULL,
  `zoom_id` varchar(255) DEFAULT NULL,
  `zoom_pw` varchar(255) DEFAULT NULL,
  `study_style` varchar(255) DEFAULT NULL,
  `group_size` varchar(255) DEFAULT NULL,
  `ta_requirement` varchar(255) DEFAULT NULL,
  `course_requirement` varchar(255) DEFAULT NULL,
  `ta_availability` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `room_description` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=143 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meetingevent`
--

INSERT INTO `meetingevent` (`id`, `meeting_name`, `host_name`, `zoom_id`, `zoom_pw`, `study_style`, `group_size`, `ta_requirement`, `course_requirement`, `ta_availability`, `start_time`, `room_description`, `status`) VALUES
(138, 'test1', 'lsydsb', '75241610205', '123', 'Quiet', 'less than 5', 'Yes', 'Yes', 'Yes', '2020-12-07 18:00:00', 'test1', NULL),
(139, 'test2', 'lsydsb', '77754278457', '123', 'Quiet', 'less than 5', 'Yes', 'Yes', 'Yes', '2020-12-10 06:59:00', 'test2', NULL),
(140, 'test3', 'lsydsb', '71890894133', 'test3', 'Quiet', 'less than 5', 'Yes', 'Yes', 'Yes', '2020-12-11 07:00:00', 'test3', NULL),
(141, 'testtest', 'winter', '73976774526', '123', 'Quiet', 'less than 5', 'Yes', 'Yes', NULL, '2020-12-07 19:00:00', 'testtest', NULL),
(142, 'test4', 'winter', '75357685022', '123', 'Quiet', 'less than 5', 'Yes', 'Yes', NULL, '2020-12-09 21:16:00', '123', NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
