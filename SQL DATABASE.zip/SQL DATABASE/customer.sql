-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 07, 2020 at 12:40 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `age` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `faculty` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `createTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `identity` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `username`, `firstname`, `email`, `age`, `gender`, `faculty`, `password`, `createTime`, `identity`) VALUES
(8, 'lsydsb', 'lsy', 'guoj0025@e.ntu.edu.sg', '11', 'Male', 'eee', '202cb962ac59075b964b07152d234b70', '2020-12-05 09:19:14', 'Teaching Assistant'),
(9, 'lll', 'll', 'slyu003@e.ntu.edu.sg', '23', 'Female', 'eee', '202cb962ac59075b964b07152d234b70', '2020-09-15 12:36:14', NULL),
(10, 'gjx', 'qq', 'guoj0025@e.ntu.edu.sg', '21', 'Female', 'eee', 'b2ca678b4c936f905fb82f2733f5297f', '2020-09-16 06:10:12', NULL),
(11, 'gjx123', 'Jx', 'GUOJ0025@e.ntu.edu.sg', '13', 'Female', 'eee', '698d51a19d8a121ce581499d7b701668', '2020-10-24 09:23:55', NULL),
(15, 'gjxx', 'xx', 'GUOJ0025@e.ntu.edu.sg', '21', 'Female', 'eee', '698d51a19d8a121ce581499d7b701668', '2020-10-24 10:02:26', 'Teaching Assistant'),
(16, '', '', '', '', '', '', 'd41d8cd98f00b204e9800998ecf8427e', '2020-10-24 10:14:28', ''),
(17, 'zzy', 'zzy', 'slyu003@e.ntu.edu.sg', '23', 'Female', 'eee', 'c53001d04a23cf3376f85d56ef4d4b6f', '2020-10-28 01:13:37', 'Teaching Assistant'),
(18, 'zzz', 'zzy', 'slyu003@e.ntu.edu.sg', '23', 'Female', 'eee', '202cb962ac59075b964b07152d234b70', '2020-10-28 01:25:23', 'Teaching Assistant'),
(19, 'test', 'test', 'i00000@e.ntu.edu.sg', '18', 'Male', 'eee', 'c4ca4238a0b923820dcc509a6f75849b', '2020-12-01 03:13:18', 'Student'),
(20, 'winter', 'lll', 'slyu003@e.ntu.edu.sg', '23', 'Female', 'eee', '202cb962ac59075b964b07152d234b70', '2020-12-07 02:14:59', 'Student');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
