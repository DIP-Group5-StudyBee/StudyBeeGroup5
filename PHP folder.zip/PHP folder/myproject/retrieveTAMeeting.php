<?php require_once('Connections/connDB.php'); ?>
<?php
$response = array();

$input = file_get_contents("php://input");
$jsonObj = json_decode($input, true);
$requestType = $jsonObj['type'];
$study_style = $jsonObj['study_style'];
$group_size = $jsonObj['group_size'];
$ta_requirement = $jsonObj['ta_requirement'];
$course_requirement = $jsonObj['course_requirement'];
// date_default_timezone_set('Asia/Singapore');
// $study_style = "Quiet";
// $group_size = "less than 8";
// $ta_requirement = "Yes";
// $course_requirement = "Yes";

$query_rsEvent = sprintf("SELECT * FROM meetingevent WHERE  ta_requirement = 'Yes' and ta_availability = 'NULL'");

$rsEvent = mysqli_query($connDB, $query_rsEvent);

$response["type"] = $requestType;

while($row = mysqli_fetch_assoc($rsEvent)){
    $response['results'][] = array(
        "meeting_name"=> $row['meeting_name'],
        "host_name" => $row['host_name'],
        "group_size" => $row['group_size'],
        // "ta_requirement" => $row['ta_requirement'],
        "room_description" => $row['room_description'],
        "start_time" => $row['start_time'],
        "zoom_id" => $row['zoom_id'],
        "zoom_pw" => $row['zoom_pw'],
        "meeting_id" => $row['id']
    );
}

$response["status"] = "OK";

echo json_encode($response);

mysqli_close($connDB);
?>
