<?php require_once('Connections/connDB.php'); ?>
<?php
$response = array();

$input = file_get_contents("php://input");
$jsonObj = json_decode($input, true);
$requestType = $jsonObj['type'];
$study_style = $jsonObj['study_style'];
$group_size = $jsonObj['group_size'];
$ta_requirement = $jsonObj['ta_requirement'];
$course_requirement = $jsonObj['course_requirement'];
$identity = $jsonObj['identity'];
// date_default_timezone_set('Asia/Singapore');
// $study_style = "Quiet";
// $group_size = "less than 8";
// $ta_requirement = "Yes";
// $course_requirement = "Yes";
//Replace with the column name 
if($identity == 'Teaching Assistant'){
    
    //account is a TA
    $query_rsEvent = sprintf("SELECT * FROM meetingevent WHERE study_style LIKE '%s' and group_size LIKE '%s'
    and ta_requirement LIKE '%s' and course_requirement LIKE '%s'", $study_style, $group_size, $ta_requirement, $course_requirement);
    
}
else{
    //the account is a studentS
    $query_rsEvent = sprintf("SELECT * FROM meetingevent WHERE study_style LIKE '%s' and group_size LIKE '%s'
    and ta_availability LIKE '%s' and course_requirement LIKE '%s'", $study_style, $group_size, $ta_requirement, $course_requirement);
}

$rsEvent = mysqli_query($connDB, $query_rsEvent);

$response["type"] = $requestType;

while($row = mysqli_fetch_assoc($rsEvent)){
    $response['results'][] = array(
        "meeting_name"=> $row['meeting_name'],
        "host_name" => $row['host_name'],
        "group_size" => $row['group_size'],
        "ta_requirement" => $row['ta_requirement'],
        "room_description" => $row['room_description'],
        "start_time" => $row['start_time'],
        "zoom_id" => $row['zoom_id'],
        "zoom_pw" => $row['zoom_pw']
    );
}

$response["status"] = "OK";

echo json_encode($response);

mysqli_close($connDB);
?>
