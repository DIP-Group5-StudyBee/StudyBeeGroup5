<?php require_once('Connections/connDB.php'); ?>
<?php
$response = array();
	
$input = file_get_contents("php://input");
$jsonObj = json_decode($input, true);
$name = $jsonObj['name'];
$greeting = $jsonObj['greeting'];
$requestType = $jsonObj['type'];
		

	$query_rsInsertProfile = sprintf("INSERT INTO profile (name, greeting) VALUES ('%s', '%s')", $name, $greeting);
	$rsInsertProfile = mysqli_query($connDB, $query_rsInsertProfile);
	$rsID = mysqli_insert_id($connDB);
				
	$response["type"] = $requestType;
	$response["id"] = $rsID;
	$response["name"] = $name;
	$response["greeting"] = $greeting;
	if($rsInsertProfile != 0)
	{
		$response["status"] = "OK";
	}
	else
	{
		$response["status"] = "NOK";
	}

echo json_encode($response);

mysqli_close($connDB);
?>