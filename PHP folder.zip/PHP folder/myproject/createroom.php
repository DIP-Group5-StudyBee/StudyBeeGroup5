<?php require_once('Connections/connDB.php'); ?>
<?php
$response = array();
	
$input = file_get_contents("php://input");
$jsonObj = json_decode($input, true);
$requestType = $jsonObj['type'];
$meetingName = $jsonObj['meeting_name'];
$studyStyle = $jsonObj['study_style'];
$groupSize = $jsonObj['group_size'];
$taRequirement = $jsonObj['ta_requirement'];
$courseRequirement = $jsonObj['course_requirement'];
$roomDescription = $jsonObj['room_description'];
$hostName = $jsonObj['host_name'];

// $meetingName = "123";
// $studyStyle = "quiet";
// $groupSize = "2-5";
// $taRequirement = "Yes";
// $courseRequirement = "Yes";
// $roomDescription = "123";

// $rsInsertRoom = 0;

	$query_rsInsertRoom = sprintf("INSERT INTO meetingevent (host_name, meeting_name, study_style, group_size, ta_requirement, course_requirement, room_description) VALUES ('%s','%s', '%s', '%s', '%s', '%s', '%s')",$hostName, $meetingName, $studyStyle, $groupSize, $taRequirement, $courseRequirement, $roomDescription);
	// $query_rsInsertRoom = sprintf("INSERT INTO meetingevent (meeting_name, study_style, group_size, ta_requirement, course_requirement, room_description) VALUES ('1', '1', '1', '1', '1', '1')");
	$rsInsertRoom = mysqli_query($connDB, $query_rsInsertRoom);
	$rsID = mysqli_insert_id($connDB);
				
	$response["type"] = $requestType;
	$response["id"] = $rsID;
    $response["meeting_name"] = $meetingName;
    $response["study_style"] = $studyStyle;
    $response["group_size"] = $groupSize;
    $response["ta_requirement"] = $taRequirement;
    $response["course_requirement"] = $courseRequirement;
    $response["room_description"] = $roomDescription;
    $response["host_name"] = $hostName;


	if($rsInsertRoom != 0)
	{
		$response["status"] = "OK";
		$response["id"] = $rsID;
	}
	else
	{
		$response["status"] = "NOK";
	}

echo json_encode($response);

mysqli_close($connDB);
?>