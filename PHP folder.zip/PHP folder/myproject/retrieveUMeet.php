<?php require_once('Connections/connDB.php'); ?>
<?php
$rows = array();
$arrays = array();
$response = array();

$input = file_get_contents("php://input");
$jsonObj = json_decode($input, true);
//change to get from userid instead of 
$user_id = $jsonObj['user_id'];
$start_time = $jsonObj['start_time'];
$requestType = $jsonObj['type'];

$query_rsUser = sprintf("SELECT * FROM meetingrecord WHERE user_id = '%d' AND meeting_time >='%s' ORDER BY meeting_time ASC LIMIT 3",$user_id,$start_time);

$rsUser = mysqli_query($connDB, $query_rsUser);
$userfound = mysqli_num_rows($rsUser);
$i = 0;
if($userfound >= 1){
    while($row_rsUser = mysqli_fetch_assoc($rsUser)){
    $stri = (string)$i;
    $arrays["type"] = $requestType;
    $arrays["user_id".$stri] = (int)$row_rsUser['user_id'];
    $arrays["meeting_id".$stri] = (int)$row_rsUser['meeting_id'];
    $arrays["meeting_name".$stri] = $row_rsUser['meeting_name'];
    $arrays["meeting_time".$stri] = $row_rsUser['meeting_time'];
    $arrays["status"] = "OK";
    $i = $i + 1;
    }
    $arrays["number"] = $i;
}  
else{
    $arrays["type"] = $requestType;
    $arrays["status"] = "NOK";
}


echo json_encode($arrays);


mysqli_close($connDB);
?>
