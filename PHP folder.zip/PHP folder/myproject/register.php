<?php require_once('Connections/connDB.php'); ?>
<?php
$response = array();
	
$input = file_get_contents("php://input");
$jsonObj = json_decode($input, true);
$username = $jsonObj['username'];
$firstname = $jsonObj['firstname'];
$email = $jsonObj['email'];
$age = $jsonObj['age'];
$gender = $jsonObj['gender'];
$faculty = $jsonObj['faculty'];
$password = md5($jsonObj['password']);
$isTA = $jsonObj['isTA'];
$requestType = $jsonObj['type'];

// $requestType = 'REQ_UPLOAD';
// $username = "123";
// $firstname = "quiet";
// $email = "Yes";
// $age = "Yes";
// $gender = "123";
// $faculty = 'faculty';
// $password = 'password';
// $isTA = 'isTA';


	$query_rsInsertProfile = sprintf("INSERT INTO customer (username, firstname, email, age, gender, faculty, password, Identity) VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')", $username, $firstname, $email, $age, $gender, $faculty, $password, $isTA );
	$rsInsertProfile = mysqli_query($connDB, $query_rsInsertProfile);
	$rsID = mysqli_insert_id($connDB);
				
	$response["type"] = $requestType;
	$response["id"] = $rsID;
    $response["username"] = $username;
    $response["firstname"] = $firstname;
    $response["email"] = $email;
    $response["age"] = $age;
    $response["gender"] = $gender;
    $response["faculty"] = $faculty;
    $response["isTA"] = $isTA;
    $response["password"] = $jsonObj['password'];

	if($rsInsertProfile != 0)
	{
		$response["status"] = "OK";
	}
	else
	{
		$response["status"] = "NOK";
	}

echo json_encode($response);

mysqli_close($connDB);
?>