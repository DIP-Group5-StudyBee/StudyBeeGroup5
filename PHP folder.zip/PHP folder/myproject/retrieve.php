<?php require_once('Connections/connDB.php'); ?>
<?php
$response = array();

$input = file_get_contents("php://input");
$jsonObj = json_decode($input, true);
$username = $jsonObj['username'];
$password = md5($jsonObj['password']);
$requestType = $jsonObj['type'];

$query_rsUser = sprintf("SELECT * FROM customer WHERE username = '%s' and password = '%s'",$username, $password);

$rsUser = mysqli_query($connDB, $query_rsUser);
$userfound = mysqli_num_rows($rsUser);

if($userfound >= 1){
    $row_rsUser = mysqli_fetch_assoc($rsUser);
    $response["type"] = $requestType;
    $response["id"] = (int)$row_rsUser['id'];
    $response["username"] = $row_rsUser['username'];
    $response["firstname"] = $row_rsUser['firstname'];
    $response["email"] = $row_rsUser['email'];
    $response["age"] = $row_rsUser['age'];
    $response["gender"] = $row_rsUser['gender'];
    $response["faculty"] = $row_rsUser['faculty'];
    $response["password"] = $jsonObj['password'];
    $response["createTime"] = $row_rsUser['createTime'];
    $response["identity"] = $row_rsUser['identity'];
    $response["status"] = "OK";
}  
else{
    $response["type"] = $requestType;
    $response["status"] = "NOK";
}

echo json_encode($response);

mysqli_close($connDB);
?>
