<?php require_once('Connections/connDB.php'); ?>
<?php
$response = array();
	
$input = file_get_contents("php://input");
$jsonObj = json_decode($input, true);
$meetingName = $jsonObj['meeting_name'];
$studyStyle = $jsonObj['study_style'];
$groupSize = $jsonObj['group_size'];
$taRequirement = $jsonObj['ta_requirement'];
$courseRequirement = $jsonObj['course_requirement'];
$roomDescription = $jsonObj['room_description'];
$requestType = $jsonObj['type'];

	$query_rsInsertEvent = sprintf("INSERT INTO meetingevent (meeting_name,study_style,group_size,ta_requirement,course_requirement,room_description) VALUES ('%s', '%s', '%s', '%s', '%s', '%s')", $meetingName, $studyStyle,$groupSize,$taRequirement,$courseRequirement,$roomDescription);
	$rsInsertEvent = mysqli_query($connDB, $query_rsInsertEvent);
	$rsID = mysqli_insert_id($connDB);
				
	$response["type"] = $requestType;
	$response["id"] = $rsID;
    $response["meeting_name"] = $meetingName;
    $response["study_style"] = $studyStyle;
    $response["group_size"] = $groupSize;
    $response["ta_requirement"] = $taRequirement;
    $response["course_requirement"] = $courseRequirement;
    $response["room_description"] = $roomDescription;

	if($rsInsertEvent != 0)
	{
		$response["status"] = "OK";
	}
	else
	{
		$response["status"] = "NOK";
	}

echo json_encode($response);

mysqli_close($connDB);
?>