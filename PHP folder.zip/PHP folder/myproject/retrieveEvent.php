<?php require_once('Connections/connDB.php'); ?>
<?php
$response = array();

$input = file_get_contents("php://input");
$jsonObj = json_decode($input, true);
$study_style = $jsonObj['study_style'];
$group_size = $jsonObj['group_size'];
$ta_requirement = $jsonObj['ta_requirement'];
$course_requirement = $jsonObj['course_requirement'];
$requestType = $jsonObj['type'];

$query_rsUser = sprintf("SELECT * FROM meetingevent WHERE study_style = '1' and group_size = '1'
and ta_requirement = '1' and course_requirement = '1'");
// $query_rsUser = sprintf("SELECT * FROM meetingevent WHERE study_style = '%s' and group_size = '%s'
// and ta_requirement = '%s' and course_requirement = '%s'",$study_style, $group_size, $ta_requirement, $course_requirement);

$rsUser = mysqli_query($connDB, $query_rsUser);
$userfound = mysqli_num_rows($rsUser);

if($userfound >= 1){
    $row_rsUser = mysqli_fetch_assoc($rsUser);
    $response["type"] = $requestType;
    $response["id"] = (int)$row_rsUser['id'];
    $response["meeting_name"] = $row_rsUser['meeting_name'];
    $response["host_name"] = $row_rsUser['host_name'];
    $response["zoom_id"] = $row_rsUser['zoom_id'];
    $response["zoom_pw"] = $row_rsUser['zoom_pw'];
    $response["study_style"] = $row_rsUser['study_style'];
    $response["group_size"] = $row_rsUser['group_size'];
    $response["ta_requirement"] = $jsonObj['ta_requirement'];
    $response["course_requirement"] = $row_rsUser['course_requirement'];
    $response["start_time"] = $row_rsUser['start_time'];
    $response["room_description"] = $row_rsUser['room_description'];
    $response["status"] = "OK";
}  
else{
    $response["type"] = $requestType;
    $response["status"] = "NOK";
}

echo json_encode($response);

mysqli_close($connDB);
?>