1. Enable allow all access at Apache http.conf
2. Enable php_curl at PHP Extension
