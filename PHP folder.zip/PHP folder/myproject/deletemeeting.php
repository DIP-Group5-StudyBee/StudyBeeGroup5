<?php require_once('Connections/connDB.php'); ?>
<?php
$response = array();

$input = file_get_contents("php://input");
$jsonObj = json_decode($input, true);
$zoom_id = $jsonObj['zoom_id'];
$requestType = $jsonObj['type'];

//$query_deletemeeting = sprintf("DELETE from meetingevent WHERE zoom_id = 79056003030");
$query_deletemeeting = sprintf("DELETE from meetingevent WHERE zoom_id = %s",$zoom_id);

$rsMeeting = mysqli_query($connDB, $query_deletemeeting);

$rc = mysqli_affected_rows($connDB);

if($rc > 0){
    $response["status"] = "OK";
}
else{
    $response["status"] = "NOK";
}
    


echo json_encode($response);

mysqli_close($connDB);
?>