<?php require_once('Connections/connDB.php'); ?>
<?php
$response = array();

$input = file_get_contents("php://input");
$jsonObj = json_decode($input, true);
$id = $jsonObj['id'];
$requestType = $jsonObj['type'];

$query_rsUser = sprintf("SELECT * FROM profile WHERE id = %s",$id);
$rsUser = mysqli_query($connDB, $query_rsUser);
$row_rsUser = mysqli_fetch_assoc($rsUser);

$response["type"] = $requestType;
$response["id"] = $id;
$response["name"] = $row_rsUser['name'];
$response["greeting"] = $row_rsUser['greeting'];

		$response["status"] = "OK";


echo json_encode($response);

mysqli_close($connDB);
?>