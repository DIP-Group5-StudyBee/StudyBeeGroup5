<?php require_once('Connections/connDB.php'); ?>
<?php
$response = array();
	
$input = file_get_contents("php://input");
$jsonObj = json_decode($input, true);
$id = $jsonObj['id'];
$username = $jsonObj['username'];
$firstname = $jsonObj['firstname'];
$email = $jsonObj['email'];
$age = $jsonObj['age'];
$gender = $jsonObj['gender'];
$faculty = $jsonObj['faculty'];
$password = md5($jsonObj['password']);
$requestType = $jsonObj['type'];

	$query_rsUpdate = sprintf("UPDATE customer SET username ='%s', firstname = '%s', email = '%s', age = '%s', gender ='%s' ,faculty = '%s',password = '%s' WHERE id = '%d'", $username, $firstname,$email,$age,$gender,$faculty,$password,$id);
	$rsUpdateProfile = mysqli_query($connDB, $query_rsUpdate);

				
	$response["type"] = $requestType;
	$response["id"] = $id;
    $response["username"] = $username;
    $response["firstname"] = $firstname;
    $response["email"] = $email;
    $response["age"] = $age;
    $response["gender"] = $gender;
    $response["faculty"] = $faculty;
    $response["password"] = $password;

	if($rsUpdateProfile != 0)
	{
		$response["status"] = "OK";
	}
	else
	{
		$response["status"] = "NOK";
	}

echo json_encode($response);

mysqli_close($connDB);
?>