<?php require_once('Connections/connDB.php'); ?>
<?php
$response = array();
	
$input = file_get_contents("php://input");
$jsonObj = json_decode($input, true);
$id = $jsonObj['meeting_id'];
$ta_availability = $jsonObj['ta_availability'];
$requestType = $jsonObj['type'];


	$query_rsUpdate = sprintf("UPDATE meetingevent SET ta_availability ='%s' WHERE id = %s",$ta_availability, $id);
	$rsUpdateProfile = mysqli_query($connDB, $query_rsUpdate);

				
	/*$response["type"] = $requestType;
	$response["id"] = $id;
    $response["username"] = $username;
    $response["firstname"] = $firstname;
    $response["email"] = $email;
    $response["age"] = $age;
    $response["gender"] = $gender;
    $response["faculty"] = $faculty;
    $response["password"] = $password;*/

    //$response["room_description"] = $room_description;
    $response["ta_availability"] = $ta_availability;

	if($rsUpdateProfile != 0)
	{
		$response["status"] = "OK";
	}
	else
	{
		$response["status"] = "NOK";
	}

echo json_encode($response);

mysqli_close($connDB);
?>