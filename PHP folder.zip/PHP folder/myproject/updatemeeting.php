<?php require_once('Connections/connDB.php'); ?>
<?php
$response = array();
	
$input = file_get_contents("php://input");
$jsonObj = json_decode($input, true);
// $id = 54;
// $zoom_id = "321312312";
// $zoom_pw = "test";
// $start_time = "2016-02-26 19:12:19";
// $requestType = "1002";
$id = $jsonObj['localmeetingid'];
$zoom_id = $jsonObj['zoom_id'];
$zoom_pw = $jsonObj['zoom_pw'];
$start_time = $jsonObj['start_time'];
$requestType = $jsonObj['type'];
$query_meetingUpdate = sprintf("UPDATE meetingevent SET zoom_id ='%s', zoom_pw = '%s', start_time = '%s' WHERE id = '%d'", $zoom_id, $zoom_pw,$start_time, $id);
$meetingUpdate = mysqli_query($connDB, $query_meetingUpdate);

			
$response["type"] = $requestType;
$response["id"] = $id;
$response["zoom_id"] = $zoom_id;
$response["zoom_pw"] = $zoom_pw;
$response["start_time"] = $start_time;

if($meetingUpdate != 0)
{
	$response["status"] = "OK";
}
else
{
	$response["status"] = "NOK";
}

echo json_encode($response);

mysqli_close($connDB);
?>