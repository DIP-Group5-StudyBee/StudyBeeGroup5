<?php require_once('Connections/connDB.php'); ?>
<?php
$response = array();

$input = file_get_contents("php://input");
$jsonObj = json_decode($input, true);
$studyStyle = $jsonObj['study_style'];
$groupSize = ($jsonObj['group_size']);
$teachingAssistant = ($jsonObj['ta_requirement']);
$course = ($jsonObj['course_requirement']);
$requestType = $jsonObj['type'];

$query_rsUser = sprintf("SELECT * FROM meetingEvent WHERE study_style = '%s' and group_size = '%s' and ta_requirement = '%s'and course_requirement = '%s'",$studyStyle, $groupSize, $teachingAssistant, $course);

$rsUser = mysqli_query($connDB, $query_rsUser);
$userfound = mysqli_num_rows($rsUser);

if($userfound >= 1){
    $row_rsUser = mysqli_fetch_assoc($rsUser);
    $response["type"] = $requestType;
    $response["id"] = (int)$row_rsUser['id'];
    $response["study_style"] = $studyStyle;
    $response["group_size"] = $groupSize;
    $response["ta_requirement"] = $teachingAssistant;
    $response["course_requirement"] = $course;
    $response["status"] = "OK";
}  
else{
    $response["type"] = $requestType;
    $response["status"] = "NOK";
}

echo json_encode($response);

mysqli_close($connDB);
?>
