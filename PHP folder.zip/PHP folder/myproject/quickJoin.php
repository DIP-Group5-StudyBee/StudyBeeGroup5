<?php require_once('Connections/connDB.php'); ?>
<?php
$response = array();

$input = file_get_contents("php://input");
$jsonObj = json_decode($input, true);
$start_time = $jsonObj['start_time'];
$isTA = $jsonObj['isTA'];
$requestType = $jsonObj['type'];
$user_id = $jsonObj['user_id'];

$query_rsUser = sprintf("SELECT * FROM meetingevent WHERE start_time <='%s' order by `start_time` desc limit 1",$start_time); 
$rsUser = mysqli_query($connDB, $query_rsUser);
$meetfound = mysqli_num_rows($rsUser);

if($meetfound >= 1){
	$row_rsUser = mysqli_fetch_assoc($rsUser);
	$response["type"] = $requestType;
	$response["id"] = $row_rsUser['id'];
	$response["zoom_id"] = $row_rsUser['zoom_id'];
	$response["room_description"] = $row_rsUser['room_description'];
	$response["zoom_pw"] = $row_rsUser['zoom_pw'];

	$meeting_id = $row_rsUser['id'];
	$meeting_name = $row_rsUser['meeting_name'];
	$meeting_time = $row_rsUser['start_time'];

	if($isTA == "Teaching Assistant"){
	 	$id = $row_rsUser['id'];
		$ta_availability = "Yes";
		$query_rsUpdate = sprintf("UPDATE meetingevent SET ta_availability ='%s' WHERE id = %s",$ta_availability, $id);
		$rsUpdateTA = mysqli_query($connDB, $query_rsUpdate);
	}

	$query_rsInsertEvent = sprintf("INSERT INTO meetingrecord (`user_id`,meeting_id,meeting_name,meeting_time) VALUES ('%s', '%s', '%s', '%s')", $user_id, $meeting_id,$meeting_name,$meeting_time);
	$rsInsertEvent = mysqli_query($connDB, $query_rsInsertEvent);
	$rsID = mysqli_insert_id($connDB);
				

	if($rsInsertEvent != 0)
	{
		$response["status"] = "OK";
	}
	else
	{
		$response["status"] = "invert meeting record NOK";
	}
}
else{
    $response["type"] = $requestType;
    $response["status"] = "NOK";
}


echo json_encode($response);

mysqli_close($connDB);
?>