<?php require_once('Connections/connDB.php'); ?>
<?php
$response = array();
	
$input = file_get_contents("php://input");
$jsonObj = json_decode($input, true);
$user_id = $jsonObj['user_id'];
$meeting_id = $jsonObj['meeting_id'];
$meeting_name = $jsonObj['meeting_name'];
$meeting_time = $jsonObj['meeting_time'];
$requestType = $jsonObj['type'];


	$query_rsInsertEvent = sprintf("INSERT INTO meetingrecord (`user_id`,meeting_id,meeting_name,meeting_time) VALUES ('%s', '%s', '%s', '%s')", $user_id, $meeting_id,$meeting_name,$meeting_time);
	$rsInsertEvent = mysqli_query($connDB, $query_rsInsertEvent);
	$rsID = mysqli_insert_id($connDB);
				


	if($rsInsertEvent != 0)
	{
		$response["status"] = "OK";
	}
	else
	{
		$response["status"] = "NOK";
	}

echo json_encode($response);

mysqli_close($connDB);
?>